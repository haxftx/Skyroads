#pragma once
//#include <ctime>
#include <deque>
#include <vector>

// date despre platforme
#define NoLines 10
#define NoPlatf 7
#define Null 100

// culorile
#define white glm::vec3(1, 1, 1)
#define red glm::vec3(1, 0, 0)
#define green glm::vec3(0, 1, 0)
#define blue glm::vec3(0, 0, 1)
#define orange glm::vec3(1, 0.647f, 0)
#define purple glm::vec3(0.48f, 0.4f, 0.55f)
#define yellow glm::vec3(1, 1, 0)
#define pink glm::vec3(1, 0.411f, 0.705f)


class Platform { // informatiile despre platforme
public:

	glm::vec3 color;
	float z;
	bool profit;

	Platform(glm::vec3 color, float z, const bool profit = false) {
		this->color = color;
		this->z = z;
		this->profit = profit;
	}

	static void createPlatforms(std::deque<std::vector<Platform>> &platforms) {
		// creeaza platformele initiale, toate simple(blue)
		std::vector <Platform> v, v1;
		for (int i = 0; i < NoPlatf; i++) // prileme 5 sunt ful
			v1.push_back(Platform(blue, 0));
		platforms.push_back(v1);
		for (int i = 1; i < NoLines; i++) {
			// pentru restul liniilor
			while (isOk(v1, v)) {// verific linia de platforme
				v.clear(); // daca nu generez una noua
				for (int j = 0; j < NoPlatf; j++) {
					if ((rand() % 2) == 1) {
						v.push_back(Platform(blue, -1.2 * i));
					}
					else {
						v.push_back(Platform(blue, Null));
					}
				}
			} // verific trecere de pe una pe alt si o adaug 
			changeX(v, v1);
			platforms.push_back(v);
			v1 = v;
			v.clear();

		}
	}

	static void addPlatform(std::deque<std::vector<Platform>>& platforms) {
		// adauga o noua platforma la sfarsit
		std::vector<Platform> v, x = platforms.back();
		platforms.pop_front();
		int count;
		int probability;
		//srand(time(0));
		while (isOk(v, x)) { // daca sa genera platforma buna
			v.clear();
			count = 0;
			for (int j = 0; j < NoPlatf; j++) {
				probability = rand() % 100;
				if ((rand() % 2) == 1) { // tipul platformei cu o probabilitate
					if (probability < 10) { // 10%
						v.push_back(Platform(green, -1.2 * (NoLines - 1), true));
					}
					else if (probability < 40) { // 30%
						v.push_back(Platform(yellow, -1.2 * (NoLines - 1), true));
					}
					else if (probability < 70) { // 30%
						v.push_back(Platform(orange, -1.2 * (NoLines - 1), true));
					}
					else if (probability < 75) { // 5%
						v.push_back(Platform(pink, -1.2 * (NoLines - 1), true));
					
					} else if (probability < 80 && count > 1) { // 5%
						v.push_back(Platform(red, -1.2 * (NoLines - 1), true));
						count++;
					} else v.push_back(Platform(blue, -1.2 * (NoLines - 1))); // 20%
				} else { // platforma lipsa
					v.push_back(Platform(blue, Null));
				}
			}
		} // verific trecere de pe una pe alt si o adaug
		changeX(v, platforms.back());
		platforms.push_back(v);
	}
	
	static bool bandOK(int b, std::vector <Platform> platform) {
		// returneaz true/false daca are vecini o platforma din fata sau spate
		if (b == 0) {
			if (platform[b].z != Null || platform[b + 1].z != Null)
				return true;
		} else if (b == NoPlatf - 1) {
			if (platform[b].z != Null || platform[b - 1].z != Null)
				return true;
		} else {
			if (platform[b].z != Null || platform[b - 1].z != Null || platform[b + 1].z != Null)
				return true;
		}
		return false;
	}

private:
	static void changeX(std::vector<Platform> &newPlatform, std::vector <Platform> lastPlatform) {
		// verifica si pastreaza doar platformele pe care pot ajunge din lastPlatform pe newPlatform
		for (int i = 0; i < NoPlatf; i++) {
			// verific daca are vecini la maxim |1| diderenta
			if (newPlatform[i].z != Null) {
				if (!bandOK(i, lastPlatform))
					newPlatform[i].z = Null;
			}
		}
	}

	static bool isOk(std::vector <Platform> newPlatform, std::vector <Platform> lastPlatform) {
		// verifica daca pot ajunge de pe lastPlatform pe newPlatform si retuneaza true daca nu si false daca da
		if (newPlatform.size() == 0 || lastPlatform.size() == 0)
			return true;
		for (int i = 0; i < NoPlatf; i++) {
			if (newPlatform[i].z != Null && bandOK(i, lastPlatform))
				return false;
			
		}
		return true;
	}
};

#pragma once