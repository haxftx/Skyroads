#pragma once
#include <Component/SimpleScene.h>
#include "TemaCamera.h"
#include "Platform.h"
#include "Transform2D.h"
#include "Object2D.h"
#include <string>
#include <iostream>
#include <Core/Engine.h>

#define LEN_GAME 160
#define H_GAME 20
#define MAX_SPEED 1.5
#define MIN_SPEED 0.5
#define T_MAX_SPEED 3
#define D_Platform 1.5
#define MAX_FUEL 10
#define MAX_SPACE 2
#define MAX_LIFE 7


class Tema2 : public SimpleScene
{
public:
	Tema2();
	~Tema2();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;

	void RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix,
					const glm::vec3& color = glm::vec3(1), const bool dist = false);
	void set_default(void);
	void show(float dtime);
	void show_line(std::vector<Platform>& platform, bool& swap, float time, int line);
	void Fcontinue(void);
	void show2D(void);
	void showPlayer(void);

protected:
	Tema::Camera* camera;
	glm::ivec2 resolution;
	glm::mat4 projectionMatrix;
	std::deque<std::vector<Platform>> platforms;
	float fov = 110.f;
	bool game_over;
	bool is_first;
	float up;
	float dist_x;
	float speed;
	float min_speed;
	int stop;
	float fuel;
	float time_max_speed;
	bool is_up;
	float timp;
	bool distortion;
	int count_distortion;
	int count_space;
	int life;
};
#pragma once