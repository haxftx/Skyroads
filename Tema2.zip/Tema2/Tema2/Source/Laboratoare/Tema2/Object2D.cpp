#include "Object2D.h"
#include <Core/Engine.h>

Mesh* Object2D::CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{ // creeaza un patrat
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(length, 0, 0), color),
		VertexFormat(corner + glm::vec3(length, length, 0), color),
		VertexFormat(corner + glm::vec3(0, length, 0), color)
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);

	return square;
}

Mesh* Object2D::CreateGameOver(std::string name, glm::vec3 color)
{	// creez "GAME OVER"
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices =
	{	// G
		VertexFormat(corner + glm::vec3(10, 20, 0), color),
		VertexFormat(corner + glm::vec3(0, 20, 0), color),
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(10, 0, 0), color),
		VertexFormat(corner + glm::vec3(10, 10, 0), color),
		VertexFormat(corner + glm::vec3(5, 10, 0), color),
		// A
		VertexFormat(corner + glm::vec3(20, 0, 0), color),
		VertexFormat(corner + glm::vec3(25, 20, 0), color),
		VertexFormat(corner + glm::vec3(30, 0, 0), color),
		VertexFormat(corner + glm::vec3(22.5, 10, 0), color),
		VertexFormat(corner + glm::vec3(27.5, 10, 0), color),
		// M
		VertexFormat(corner + glm::vec3(40, 0, 0), color),
		VertexFormat(corner + glm::vec3(42.5, 20, 0), color),
		VertexFormat(corner + glm::vec3(45, 10, 0), color),
		VertexFormat(corner + glm::vec3(47.5, 20, 0), color),
		VertexFormat(corner + glm::vec3(50, 0, 0), color),
		// E
		VertexFormat(corner + glm::vec3(70, 0, 0), color),
		VertexFormat(corner + glm::vec3(60, 0, 0), color),
		VertexFormat(corner + glm::vec3(60, 20, 0), color),
		VertexFormat(corner + glm::vec3(70, 20, 0), color),
		VertexFormat(corner + glm::vec3(60, 10, 0), color),
		VertexFormat(corner + glm::vec3(70, 10, 0), color),
		// O
		VertexFormat(corner + glm::vec3(90, 0, 0), color),
		VertexFormat(corner + glm::vec3(90, 20, 0), color),
		VertexFormat(corner + glm::vec3(100, 20, 0), color),
		VertexFormat(corner + glm::vec3(100, 0, 0), color),
		// V
		VertexFormat(corner + glm::vec3(110, 20, 0), color),
		VertexFormat(corner + glm::vec3(115, 0, 0), color),
		VertexFormat(corner + glm::vec3(120, 20, 0), color),
		// E
		VertexFormat(corner + glm::vec3(140, 0, 0), color),
		VertexFormat(corner + glm::vec3(130, 0, 0), color),
		VertexFormat(corner + glm::vec3(130, 20, 0), color),
		VertexFormat(corner + glm::vec3(140, 20, 0), color),
		VertexFormat(corner + glm::vec3(130, 10, 0), color),
		VertexFormat(corner + glm::vec3(140, 10, 0), color),
		// R
		VertexFormat(corner + glm::vec3(150, 0, 0), color),
		VertexFormat(corner + glm::vec3(150, 20, 0), color),
		VertexFormat(corner + glm::vec3(160, 20, 0), color),
		VertexFormat(corner + glm::vec3(160, 10, 0), color),
		VertexFormat(corner + glm::vec3(150, 10, 0), color),
		VertexFormat(corner + glm::vec3(160, 0, 0), color),

	};

	Mesh* game = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 1, 2, 2, 3, 3, 4, 4, 5,
											6, 7, 7, 8, 9, 10,
											11, 12, 12, 13, 13, 14, 14, 15,
											16, 17, 17, 18, 18, 19, 20, 21,
											22, 23, 23, 24, 24, 25, 25, 22,
											26, 27, 27, 28,
											29, 30, 30, 31, 31, 32, 33, 34,
											35, 36, 36, 37, 37, 38, 38, 39, 39, 40 };


	game->SetDrawMode(GL_LINES);
	game->InitFromData(vertices, indices);
	return game;
}

Mesh* Object2D::CreateHeart(std::string name, glm::vec3 color)
{	// creez o inima
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner + glm::vec3(5, 0, 0), color),
		VertexFormat(corner + glm::vec3(0, 16, 0), color),
		VertexFormat(corner + glm::vec3(10, 16, 0), color),

		VertexFormat(corner + glm::vec3(10 - 10 / 8, 20, 0), color),
		VertexFormat(corner + glm::vec3(7.5, 16, 0), color),

		VertexFormat(corner + glm::vec3(5 + 5 / 4, 20, 0), color),
		VertexFormat(corner + glm::vec3(5, 16, 0), color),

		VertexFormat(corner + glm::vec3(2.5, 16, 0), color),
		VertexFormat(corner + glm::vec3(5 - 5 / 4, 20, 0), color),
		VertexFormat(corner + glm::vec3(5 / 4, 20, 0), color),

	};

	Mesh* heart = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 2, 3, 4, 4, 3, 5, 5, 4, 6, 6, 7, 8, 7, 8, 9, 9, 7, 1 };

	heart->SetDrawMode(GL_TRIANGLE_STRIP);
	heart->InitFromData(vertices, indices);
	return heart;
}
