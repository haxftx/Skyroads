
class Constants {
public:
	float NoPlatf = 5;
};