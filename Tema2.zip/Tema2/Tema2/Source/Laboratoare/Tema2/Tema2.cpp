#pragma once
#include "Tema2.h"
#include <ctime>

#define len_x 1
#define len_y 0.1
#define len_z 5

using namespace std;

Tema2::Tema2() {
}

Tema2::~Tema2(){
}

void Tema2::Init() { 
	srand(time(0));
	resolution = window->GetResolution();
	auto camera2D = GetSceneCamera();
	camera2D->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 200);
	camera2D->SetPosition(glm::vec3(0, 0, 50));
	camera2D->SetRotation(glm::vec3(0, 0, 0));
	camera2D->Update();
	GetCameraInput()->SetActive(false);

	camera = new Tema::Camera();
	camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
	camera->TranslateForward(-0.55f);

	set_default();

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Shader* shader = new Shader("ShaderTema2");
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	Mesh* square = Object2D::CreateSquare("square", glm::vec3(0, 0, 0), 20, glm::vec3(0.5, 0.5, 0.75), true);
	AddMeshToList(square);
	Mesh* game = Object2D::CreateGameOver("game", glm::vec3(0, 0, 1));
	AddMeshToList(game);
	Mesh* heart = Object2D::CreateHeart("heart", red);
	AddMeshToList(heart);

	projectionMatrix = glm::perspective(RADIANS(fov), window->props.aspectRatio, 0.5f, 400.0f);
}

void Tema2::FrameStart() {
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glm::ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema2::set_default() {
	// initializeaza datele jocului
	platforms.clear();
	Platform::createPlatforms(platforms);
	game_over = false;
	is_first = false;
	up = 0;
	dist_x = 0;
	speed = MIN_SPEED;
	min_speed = MIN_SPEED;
	stop = 1;
	fuel = MAX_FUEL;
	time_max_speed = 0;
	is_up = false;
	timp = 0;
	distortion = false;
	count_distortion = 0;
	count_space = 0;
	life = 3;
}

void Tema2::Fcontinue() { // continue cand pierd o viata
	std::deque<vector<Platform>>::iterator it = platforms.begin();
	bool flag = false;
	float dist = 0;

	for (int i = 0; i < NoPlatf; i++) { // verific daca sunt intre linii de platforme
		if ((*it)[i].z != Null && (*it)[i].z >= 1.f) {
			dist = 1.2 - (*it)[i].z;
			flag = true;
			break;
		}
		else if ((*it)[0].z != Null) break;
	}

	for (int i = 0; i < NoLines; i++) {
		if (!flag)
			break; // mut platformele mai in fata
		for (int j = 0; j < NoPlatf; j++) {
			if ((*it)[j].z != Null)
				(*it)[j].z = -1.2 * (i - 1);
		}
		it++;
	}
	// linia de platforme pe care o sa fiu
	it = platforms.begin();
	if (flag)
		it++;

	for (int i = 0; i < NoPlatf; i++) { // verfic pe ce platform sa ma pozitionez
		if ((*it)[i].z != Null && Platform::bandOK(i, *(it + 1))) {
			dist_x = (-D_Platform * (int)(NoPlatf / 2)) + 1.5 * i;
			(*it)[i].color = blue;
			(*it)[i].profit = 0;
			break;
		}
	}
}

void Tema2::show_line(vector<Platform>& platform, bool& swap, float dtime, int line) {
	glm::mat4 modelMatrix; // afiseaza o linie de platforme
	for (int j = 0; j < NoPlatf; j++) {
		// afisez fiecare platforma
		if (platform[j].z >= 1.2 && platform[j].z != Null) {
			swap = true;
		}
		if (platform[j].z != Null) {
			modelMatrix = glm::scale(glm::mat4(1), glm::vec3(len_x, len_y, len_z));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-D_Platform * (int)(NoPlatf / 2) + D_Platform * j,
																								2.f, platform[j].z));
			if (stop == 0 && line == 0 && up == 0 && dist_x == -(D_Platform * (int)(NoPlatf / 2)) + D_Platform * j) {
				if (platform[j].profit) { // coliziuni cu platforme cu profit
					platform[j].profit = false;
					if (platform[j].color == red) { // pierd o viata
						life--;
						if (life == 0)
							game_over = true;
						stop = 1;
					}
					else if (platform[j].color == yellow) {
						fuel -= 1; // se pierde combustibil
					}
					else if (platform[j].color == orange) {
						speed = MAX_SPEED; // viteza devine maxima un timp
						time_max_speed = T_MAX_SPEED;
					}
					else if (platform[j].color == green && fuel < MAX_FUEL) {
						fuel += 2; // se adauga combustibil
					}
					else if (platform[j].color == pink && life < MAX_LIFE) {
						life++; // adaug o viata
					}
					distortion = true;
				} // schimb culoare platformei
				platform[j].color = purple;
			}
			RenderMesh(meshes["box"], shaders["ShaderTema2"], modelMatrix, platform[j].color);
			platform[j].z += speed * dtime; // actualizez distanta platformei
		}
	}
}

void Tema2::show(float dtime) { // afiseaza platformele
	std::deque<vector<Platform>>::iterator it = platforms.begin();
	bool swap = false;
	if (dtime != 0.f) { // timpul combustibilului
		timp += dtime;
	} // verific platforma ce blocheaza la viteza maxima
	if (time_max_speed > 0)
		time_max_speed -= dtime;
	else time_max_speed = 0;
	// actualizez combustibilul
	fuel -= speed * 0.1 * dtime * timp / 10;
	min_speed += dtime / 100;

	for (int i = 0; i < NoLines; i++) {
		// pentru fiecare linie afisez platformele
		if (i == 0) {
			// coliziune cu spatiu gol sau fara combustibil
			if (fuel <= 0 || up == 0 && ((*it)[(dist_x / D_Platform + D_Platform * (int)(NoPlatf / 2) - 1)].z > 1 ||
									(*it)[(dist_x / D_Platform + D_Platform * (int)(NoPlatf / 2) - 1)].z == Null)) {
				if (!stop) { // scad o viata si verific daca am pirdut sau nu
					life--;
					if (life == 0)
						game_over = true;
					else {
						Fcontinue();
						stop = 1;
						if (fuel <= 0) {
							fuel = MAX_FUEL;
							timp = 0;
						}
						break;
					}
				}
				stop = 1;
			}
		}
		show_line(*it, swap, dtime, i); // afisez platfmele de pe linia i
		it++;
	}
	if (swap) { // schimb platforma iesita din scena la final
		Platform::addPlatform(platforms);
	}
}

void Tema2::show2D() { // afisez elementele 2D
	// vieti
	glm::mat3 mat = glm::mat3(1);
	mat *= Transform2D::Scale(5, 3);
	mat *= Transform2D::Translate(-10, 30);
	for (int i = 0; i < life; i++) {
		mat *= Transform2D::Translate(10, 0);
		RenderMesh2D(meshes["heart"], mat, red);
	} // combustibilul
	mat = glm::mat3(1);
	mat *= Transform2D::Scale(fuel, 1);
	RenderMesh2D(meshes["square"], mat, glm::vec3(0.8f, 0, 0.8f));
	mat = glm::mat3(1);
	mat *= Transform2D::Scale(MAX_FUEL, 1);
	RenderMesh2D(meshes["square"], mat, white);
	// viteza
	mat = glm::mat3(1);
	mat *= Transform2D::Translate(resolution.x - 10, 0);
	mat *= Transform2D::Scale(1, 5 * speed);
	if (stop) mat *= Transform2D::Scale(1, 0);
	RenderMesh2D(meshes["square"], mat, glm::vec3(0, 0.57f, 0.f));
	mat = glm::mat3(1);
	mat *= Transform2D::Translate(resolution.x - 10, 0);
	mat *= Transform2D::Scale(1, 5 * MAX_SPEED);
	RenderMesh2D(meshes["square"], mat, white);
	mat = glm::mat3(1); // bara de jos
	mat *= Transform2D::Scale(resolution.x, 8.5f);
	RenderMesh2D(meshes["square"], mat, glm::vec3(0.23f, 0.192f, 0.004f));
}

void Tema2::showPlayer() { // afisez sfera

	if (distortion) {
		count_distortion++;
		if (count_distortion == 10) {
			count_distortion = 0;
			distortion = false;
		}
	}
	glm::mat4 modelMatrix = glm::mat4(1);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(dist_x, 0.35f + up, 2.4f));
	modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f));
	RenderMesh(meshes["sphere"], shaders["ShaderTema2"], modelMatrix, white, distortion);
}

void Tema2::Update(float deltatimpSeconds) {

	// afisez platformele	
	if (stop) { // daca se opreste jocul

		if (up > -5.f && game_over) { // cade de pe platfrome
			up -= deltatimpSeconds;
			show(0);
		} else {
			if (game_over) { // daca am pierdut afisez game over
				glm::mat3 mat = glm::mat3(1);
				int coeficient = resolution.x / (LEN_GAME + 1);
				mat *= Transform2D::Translate((resolution.x - LEN_GAME*coeficient) / 2, (resolution.y - H_GAME * coeficient) / 2);
				mat *= Transform2D::Scale(coeficient, coeficient);
				RenderMesh2D(meshes["game"], shaders["VertexColor"], mat);
			}else show(0);
		}
		
	} else if (game_over) { // am pierdut reaiua jocul
		set_default();
		show(deltatimpSeconds);
	} else show(deltatimpSeconds);
	
	if (!is_first) { // afisez sau nu sfera
		showPlayer();
	}
	show2D();
	
}

void Tema2::FrameEnd() {

}

void Tema2::RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color, const bool dist) {
	if (!mesh || !shader || !shader->program)
		return;
	// trimit datele in VertexShader
	glUseProgram(shader->program);
	glUniformMatrix4fv(glGetUniformLocation(shader->program, "View"), 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(glGetUniformLocation(shader->program, "Projection"), 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(glGetUniformLocation(shader->program, "Model"), 1, GL_FALSE, glm::value_ptr(modelMatrix));
	glUniform3fv(glGetUniformLocation(shader->program, "object_color"), 1, glm::value_ptr(color));
	glUniform1f(glGetUniformLocation(shader->program, "time"), timp);
	glUniform1i(glGetUniformLocation(shader->program, "distortion"), dist);
	// desenez obiectul
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}

// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void Tema2::OnInputUpdate(float deltatimp, int mods) {
	// setez viteza daca tin apasat pe W/S +/-
	if (window->KeyHold(GLFW_KEY_W) && !stop && speed < MAX_SPEED) {
		speed += deltatimp;
	} else if (window->KeyHold(GLFW_KEY_S) && !stop && speed > min_speed && time_max_speed == 0.f) {
		speed -= deltatimp;
	} // creez animatia pentru salt
	if ((up < 1.f + 0.5f * (count_space - 1)) && is_up) {
		up += 3 * speed * deltatimp;
	} else if (up > 0.001f) {
		is_up = false;
		up -= 3 * speed * deltatimp;
	} else if (!stop) {
		up = 0;
		count_space = 0;
	}
	if (is_first) { // daca e persoana 1 sau nu
		projectionMatrix = glm::perspective(RADIANS(fov), window->props.aspectRatio, 0.55f, 200.0f);
		projectionMatrix = glm::translate(projectionMatrix, glm::vec3(-dist_x, -(0.35f + up), 0.21f));

	} else projectionMatrix = glm::perspective(RADIANS(fov), window->props.aspectRatio, 0.5f, 200.0f);
}


void Tema2::OnKeyPress(int key, int mods) {
	if (key == GLFW_KEY_P) { // pornesc jocul
		if (!game_over && stop)
			stop = !stop;
		else if (game_over && up <= -5.f)
			stop = !stop;
	}
	if (key == GLFW_KEY_C) { // trec din persoana 1 in 3
		is_first = !is_first;
	}
	if (key == GLFW_KEY_SPACE && !stop && count_space < MAX_SPACE) { // sar
		count_space++;
		is_up = true;

	} // deplasarile sanga/dreapta A/D
	if (key == GLFW_KEY_D && !stop && dist_x < (D_Platform * (int)(NoPlatf / 2))) {
		dist_x += D_Platform;
	}
	if (key == GLFW_KEY_A && !stop && dist_x > (-D_Platform * (int)(NoPlatf / 2))) {
		dist_x -= D_Platform;
	}
}

void Tema2::OnKeyRelease(int key, int mods) {
	// add key release event
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) {
	// add mouse move event

}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) {
	// add mouse button press event
}

void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) {
	// add mouse button release event
}

void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) {
}

void Tema2::OnWindowResize(int width, int height) {
	// actualizez datele
	resolution = window->GetResolution();
	auto camera2D = GetSceneCamera();
	camera2D->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera2D->SetPosition(glm::vec3(0, 0, 50));
	camera2D->SetRotation(glm::vec3(0, 0, 0));
	camera2D->Update();
	GetCameraInput()->SetActive(false);

}
#pragma once