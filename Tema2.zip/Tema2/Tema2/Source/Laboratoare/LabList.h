#pragma once


#include <Laboratoare/Tema2/Tema2.h>
#pragma once
	